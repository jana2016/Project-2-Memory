# Memory Game Project
Credits

*show cards, increase count: Matthew Cranford walkthrough part 2, 5 https://matthewcranford.com

/* modal create, open and close: https://www.youtube.com/watch?v=gLWIYk0Sd38

/*increase count: https://stackoverflow.com/questions/9186346/javascript-onclick-increment-number

/*remove stars
https://www.w3schools.com/jsref/met_node_removechild.asp
https://catalin.red/removing-an-element-with-plain-javascript-remove-method/

/*clock
https://www.youtube.com/watch?v=nD2SJ0pFAjQ

/reload page: https://www.w3schools.com/jsref/met_loc_reload.asp


To Play the Game
Open index.html on your web browser
The goal is to match all 16 cards. When cards match, they will turn green and remain visible.
Try to remember where they are - the fewer moves you make, the better your star rating!
To start over, click the restart icon!
